CREATE TABLE `activity` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_name` text,
	`event` text NOT NULL,
	`detail` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `clients` (
	`id` integer PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text,
	`currency` text NOT NULL,
	`wallet` integer NOT NULL,
	`payload` text NOT NULL,
	`fetched_at` text NOT NULL,
	`ledger_at` text
);
--> statement-breakpoint
CREATE TABLE `credits` (
	`id` integer PRIMARY KEY NOT NULL,
	`client_id` integer NOT NULL,
	`date` text NOT NULL,
	`amount` integer NOT NULL,
	`description` text
);
--> statement-breakpoint
CREATE TABLE `download_items` (
	`event_id` text NOT NULL,
	`invoice_id` integer NOT NULL,
	`source_hash` text NOT NULL,
	PRIMARY KEY(`event_id`, `invoice_id`)
);
--> statement-breakpoint
CREATE INDEX `download_invoice` ON `download_items` (`invoice_id`);--> statement-breakpoint
CREATE TABLE `downloads` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`user_name` text NOT NULL,
	`format` text NOT NULL,
	`archive_id` text,
	`status` text NOT NULL,
	`invoice_count` integer NOT NULL,
	`created_at` text NOT NULL,
	`completed_at` text,
	`error` text
);
--> statement-breakpoint
CREATE INDEX `download_time` ON `downloads` (`created_at`);--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` integer PRIMARY KEY NOT NULL,
	`client_id` integer NOT NULL,
	`number` text NOT NULL,
	`date` text NOT NULL,
	`due_date` text,
	`paid_date` text,
	`status` text NOT NULL,
	`currency` text NOT NULL,
	`client_name` text NOT NULL,
	`country` text,
	`subtotal` integer NOT NULL,
	`tax` integer NOT NULL,
	`tax2` integer NOT NULL,
	`total` integer NOT NULL,
	`credit` integer NOT NULL,
	`balance` integer NOT NULL,
	`gstin` text,
	`gst_status` text,
	`basis` text,
	`kind` text NOT NULL,
	`issues` text NOT NULL,
	`payload` text NOT NULL,
	`source_hash` text NOT NULL,
	`fetched_at` text NOT NULL,
	`review_note` text,
	`review_hash` text,
	`review_by` text,
	`review_at` text,
	`last_downloaded` text,
	`downloaded_by` text,
	`downloaded_hash` text,
	`download_count` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `invoice_dates` ON `invoices` (`date`,`id`);--> statement-breakpoint
CREATE INDEX `invoice_client` ON `invoices` (`client_id`,`date`);--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`type` text NOT NULL,
	`state` text NOT NULL,
	`params` text NOT NULL,
	`cursor` text NOT NULL,
	`total` integer DEFAULT 0 NOT NULL,
	`done` integer DEFAULT 0 NOT NULL,
	`errors` integer DEFAULT 0 NOT NULL,
	`message` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`lease` text,
	`lease_until` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `members` (
	`job_id` text NOT NULL,
	`invoice_id` integer NOT NULL,
	`state` text NOT NULL,
	`source_hash` text,
	`object_key` text,
	`size` integer,
	`format` text,
	`error` text,
	PRIMARY KEY(`job_id`, `invoice_id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` integer PRIMARY KEY NOT NULL,
	`client_id` integer NOT NULL,
	`invoice_id` integer,
	`date` text NOT NULL,
	`currency` text NOT NULL,
	`gateway` text,
	`reference` text,
	`amount_in` integer NOT NULL,
	`amount_out` integer NOT NULL,
	`fees` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `payment_client_date` ON `transactions` (`client_id`,`date`);