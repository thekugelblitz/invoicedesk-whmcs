import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
 title: "Munshi Ji · Invoice workspace",
 description: "Your WHMCS invoices, downloaded and accounted for.",
 robots: {index:false,follow:false},
 icons: {icon:"/favicon.svg"}
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
