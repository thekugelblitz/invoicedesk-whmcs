import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync('drizzle/0000_amused_ikaris.sql','utf8'));
const prepare=sql=>{let args=[];return {bind(...values){args=values;return this;},async first(){return sqlite.prepare(sql).get(...args)||null;},async all(){return {results:sqlite.prepare(sql).all(...args)};},async run(){const r=sqlite.prepare(sql).run(...args);return {meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};}};};
const objects=new Map();
export const env={DB:{prepare,async batch(values){sqlite.exec('BEGIN');try{const result=[];for(const s of values)result.push(await s.run());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}}},BUCKET:{async put(key,value){objects.set(key,typeof value==='string'?new TextEncoder().encode(value):value);},async head(key){const data=objects.get(key);return data?{size:data.byteLength}:null;},async get(key){const data=objects.get(key);return data?{size:data.byteLength,body:new Response(data).body}:null;},async delete(key){objects.delete(key);}},MUNSHI_MASTER_KEY:Buffer.alloc(32,7).toString('base64')};
