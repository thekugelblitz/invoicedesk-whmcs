import { env } from 'cloudflare:workers';
import { now } from './domain';
export function db():D1Database {if(!env.DB)throw Error('Shared database is unavailable.');return env.DB;}
export function bucket():R2Bucket {if(!env.BUCKET)throw Error('File storage is unavailable.');return env.BUCKET;}
export const one=async(sql:string,args:any[]=[])=>db().prepare(sql).bind(...args).first<any>();
export const all=async(sql:string,args:any[]=[])=>((await db().prepare(sql).bind(...args).all<any>()).results||[]);
export const run=(sql:string,args:any[]=[])=>db().prepare(sql).bind(...args).run();
export async function setting(key:string,fallback:any=null){const v=await one('SELECT value FROM settings WHERE key=?',[key]);return v?JSON.parse(v.value):fallback;}
export const set=(key:string,value:any)=>run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',[key,JSON.stringify(value)]);
export const preferences=()=>setting('preferences',{company:'HostingSpell',supplier_gstin:'',gst_labels:'gstin,gst number,gst no,gst registration',tax_is_gst:false,archive_days:7});
export const audit=(user:string,event:string,detail:any={})=>run('INSERT INTO activity(user_name,event,detail,created_at) VALUES(?,?,?,?)',[user,event,JSON.stringify(detail),now()]);
function bytes(s:string){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
function base64(b:Uint8Array){return btoa(String.fromCharCode(...b));}
async function key(){const value=env.MUNSHI_MASTER_KEY;if(!value)throw Error('The hosted encryption key is missing.');return crypto.subtle.importKey('raw',bytes(value),'AES-GCM',false,['encrypt','decrypt']);}
export async function encrypt(value:any){const iv=crypto.getRandomValues(new Uint8Array(12));const data=new TextEncoder().encode(JSON.stringify(value));return {iv:base64(iv),data:base64(new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},await key(),data)))};}
export async function connection(){const v=await setting('connection');if(!v)return null;return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(v.iv)},await key(),bytes(v.data))));}
export async function hash(value:string|Uint8Array){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',typeof value==='string'?new TextEncoder().encode(value):value as BufferSource))).map(n=>n.toString(16).padStart(2,'0')).join('');}
