# Munshi Ji — hosted edition

Private WHMCS invoice workspace with shared download tracking, GST checks, client settlement ledgers and analytics. Built on the Sites Vinext starter, TanStack Query 5 and TanStack Table 9, Cloudflare D1 and R2. The cPanel PHP edition is linked in Settings.

- The download desk is the default view; pending, downloaded and changed-version queues are shared across the workspace.
- Original PDFs use the included HMAC bridge installed beside WHMCS. The standard read-only API imports invoice data. No WHMCS invoice or client records are modified.
- Completed PDF and ZIP responses record who, when and which source version was served. CSV exports, previews and preparing ZIPs do not clear pending originals. HTML copies have separate history. Browser disk saves and downloads outside the app cannot be verified.
- Four themes: System, Light, Dark and true-black AMOLED. Bright orange accent, responsive invoice cards, accessible dialogs and reduced-motion support.
- Full client imports include invoices, transactions, refunds and credit history. Settlement ledgers are reconstructed; credit applications use invoice dates, and current WHMCS balances remain the reconciliation reference.
- GST format/checksum and evidence checks are review aids, not confirmation of active registration or legal tax treatment. Current client profiles remain distinct from invoice snapshots.

## Configure

The private hosted app uses ChatGPT sign-in. Settings stores API credentials encrypted with AES-GCM. Set MUNSHI_MASTER_KEY as a 32-byte base64 Sites runtime secret; never commit it. Configure the WHMCS API URL, read-only API identifier/secret, and optional original PDF bridge in Settings. Required actions: GetInvoices, GetInvoice, GetClientsDetails, GetCurrencies, GetTransactions and GetCredits. Secrets are not returned to the browser.

The cPanel edition additionally supports direct SELECT-only MySQL access and private PHP diagnostics. Raw TCP/MySQL connections are not available in the hosted edition.

## Development and validation

Install with the Sites dependency helper, generate migrations after schema changes with `npm run db:generate`, and build through the Sites build helper. See the supplied starter scripts for local migration/preview commands. Do not commit .env files, .wrangler state, runtime secrets or generated private records.

Run `node tests/run.mjs` for eleven integration checks with isolated SQLite/R2 fixtures. It verifies arithmetic, GSTIN checks, encryption, partial job retries, complete and cancelled downloads, repeat history, version freshness, partial ZIP membership, CSV safety, HTML escaping, and wallet/mass-pay settlement treatment. Generated ZIPs are also independently readable by Python's zipfile module.

Hosted batches are bounded to 100 invoices and 100 MB per ZIP, 500 per refresh, and 5,000 ledger display rows. A large complete client journal is rejected before replacement if it exceeds one atomic batch; use the cPanel edition for larger exports. Jobs run while the app is open and can be resumed. Production starts with no sample records; the sample workspace is explicitly labelled and never writes to the database.

Live WHMCS credentials were not supplied during development. Test your own connection, permissions, currency metadata and PDF adapter before relying on the imported data. Download history tracks only this installation.
